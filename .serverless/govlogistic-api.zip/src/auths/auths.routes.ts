import { Router } from "express";
import { login, register } from "./auths.controllers";
import asyncHandler from "../utils/errors/asyncHandler";

const router = Router();

router.post("/login", asyncHandler(login));
router.post("/register", asyncHandler(register));

router.get("/", (req, res) => {
  res.json({ message: "Hello World Auth Modules" });
});

const authsRouter = router;

export { authsRouter };
