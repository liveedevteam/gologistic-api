import { Request, Response } from 'express';

export const login = async (req: Request, res: Response) => {
    res.status(200).json({ message: "Login Success" });
}

export const register = async (req: Request, res: Response) => {
    res.status(200).json({ message: "Register Success" });
}