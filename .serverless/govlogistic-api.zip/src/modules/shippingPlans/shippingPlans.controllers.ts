import { Request, Response } from "express";
import { createShippingPlanService, deleteShippingPlanService, getShippingPlanServiceById, getShippingPlansService, updateShippingPlanService } from "./services/shippingPlans.services";

export const createShippingPlan = async (req:Request, res: Response) => {
    const { name, description, price, duration, weight, width, height, length, isActive } = req.body;
    const shippingPlan = await createShippingPlanService();
    return res.status(201).json(shippingPlan);
};

export const getShippingPlans = async (req:Request, res: Response) => {
    const { id } = req.params;
    const shippingPlans = await getShippingPlansService();
    return res.status(200).json(shippingPlans);
}

export const getShippingPlanById = async (req:Request, res: Response) => {
    const { id } = req.params;
    const shippingPlan = await getShippingPlanServiceById(id);
    return res.status(200).json(shippingPlan);
}

export const updateShippingPlan = async (req:Request, res: Response) => {
    const { id } = req.params;
    const { name, description, price, duration, weight, width, height, length, isActive } = req.body;
    const shippingPlan = await updateShippingPlanService();
    return res.status(200).json(shippingPlan);
}

export const deleteShippingPlan = async (req:Request, res: Response) => {
    const { id } = req.params;
    await deleteShippingPlanService(id);
    return res.status(204).json();
}