import { Router } from "express";
import {
  createShippingPlan,
  deleteShippingPlan,
  getShippingPlans,
  getShippingPlanById,
  updateShippingPlan,
} from "./shippingPlans.controllers";
import asyncHandler from "../../utils/errors/asyncHandler";

const router = Router();

router.delete("/:id", asyncHandler(deleteShippingPlan));

router.patch("/", asyncHandler(updateShippingPlan));

router.post("/", asyncHandler(createShippingPlan));

router.get("/:id", asyncHandler(getShippingPlanById));

router.get("/", asyncHandler(getShippingPlans));

const shippingPlansRouter = router;

export { shippingPlansRouter };
