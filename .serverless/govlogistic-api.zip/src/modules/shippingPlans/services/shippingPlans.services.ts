
export const createShippingPlanService = async () => {
    return { message: "createShippingPlanService" };
}

export const getShippingPlansService = async () => {
    return { message: "getShippingPlansService" };
}

export const getShippingPlanServiceById = async (id: string) => {
    return { message: "getShippingPlanService" };
}

export const updateShippingPlanService = async () => {
    return { message: "updateShippingPlanService" };
}

export const deleteShippingPlanService = async (id: string) => {
    return { message: "deleteShippingPlanService" };
}